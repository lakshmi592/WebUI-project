package com.redhat.qe.auto.selenium;

public interface IScreenCapture {
	
	public String screenCapture() throws Exception;

}
