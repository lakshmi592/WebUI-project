package com.redhat.qe.auto.tcms;

public interface ITestProcedureHandler {
	
	public String getLog();
	
	public void reset();

}
